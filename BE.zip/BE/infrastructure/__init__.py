"""Infrastructure layer - External services and data persistence."""
