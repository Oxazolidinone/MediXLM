"""Application layer - Use cases and business logic orchestration."""
