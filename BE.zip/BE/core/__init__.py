"""Core module - Configuration, exceptions, and utilities."""
