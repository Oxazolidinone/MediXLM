"""Domain layer - Core business logic and entities."""
